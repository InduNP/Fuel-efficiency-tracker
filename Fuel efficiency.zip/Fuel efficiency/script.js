const chatBox = document.getElementById("chat-box");
const userInput = document.getElementById("user-input");

function sendMessage() {
  const input = userInput.value.trim();
  if (!input) return;

  addMessage(input, "user");
  respondToUser(input);
  userInput.value = "";
}

function addMessage(text, sender) {
  const msg = document.createElement("div");
  msg.classList.add("message", sender);
  msg.textContent = text;
  chatBox.appendChild(msg);
  chatBox.scrollTop = chatBox.scrollHeight;
}

let waitingFor = null;
let pendingAction = null;
let data = {};

function respondToUser(input) {
  input = input.toLowerCase().trim();

  if (waitingFor === "distance") {
    const distance = parseFloat(input);
    if (isNaN(distance) || distance <= 0) {
      addMessage("Please enter a valid number for distance in kilometers.", "bot");
      return;
    }
    data.distance = distance;
    waitingFor = "fuel";
    addMessage("Got it! Now enter the amount of fuel used (in liters):", "bot");
  }

  else if (waitingFor === "fuel") {
    const fuel = parseFloat(input);
    if (isNaN(fuel) || fuel <= 0) {
      addMessage("Please enter a valid number for fuel in liters.", "bot");
      return;
    }
    data.fuel = fuel;
    data.efficiency = (data.distance / data.fuel).toFixed(2);
    addMessage(`Your fuel efficiency is ${data.efficiency} km/l 🚗`, "bot");
    waitingFor = null;

    // After efficiency is calculated, resume pending action
    if (pendingAction === "range_fuel") {
      pendingAction = null;
      waitingFor = "range_fuel";
      addMessage("Now, enter the amount of fuel you have (in liters):", "bot");
    } else if (pendingAction === "fuel_for_distance") {
      pendingAction = null;
      waitingFor = "fuel_for_distance";
      addMessage("Now, enter the distance you want to travel (in km):", "bot");
    }
  }

  else if (waitingFor === "range_fuel") {
    const fuel = parseFloat(input);
    if (isNaN(fuel) || fuel <= 0) {
      addMessage("Please enter a valid number for fuel in liters.", "bot");
      return;
    }
    if (!data.efficiency) {
      pendingAction = "range_fuel";
      addMessage("Please calculate your fuel efficiency first by typing 'calculate'.", "bot");
    } else {
      const distance = (fuel * data.efficiency).toFixed(2);
      addMessage(`You can travel approximately ${distance} km with ${fuel} liters of fuel.`, "bot");
    }
    waitingFor = null;
  }

  else if (waitingFor === "fuel_for_distance") {
    const dist = parseFloat(input);
    if (isNaN(dist) || dist <= 0) {
      addMessage("Please enter a valid number for distance in kilometers.", "bot");
      return;
    }
    if (!data.efficiency) {
      pendingAction = "fuel_for_distance";
      addMessage("Please calculate your fuel efficiency first by typing 'calculate'.", "bot");
    } else {
      const fuelRequired = (dist / data.efficiency).toFixed(2);
      addMessage(`You will need approximately ${fuelRequired} liters of fuel to travel ${dist} km.`, "bot");
    }
    waitingFor = null;
  }

  else {
    // General input handling
    if (input.includes("calculate")) {
      waitingFor = "distance";
      addMessage("Sure! Please enter the distance traveled (in km):", "bot");
    }

    else if (input.includes("how far") || input.includes("travel with")) {
      if (!data.efficiency) {
        pendingAction = "range_fuel";
        addMessage("Please calculate your fuel efficiency first by typing 'calculate'.", "bot");
      } else {
        waitingFor = "range_fuel";
        addMessage("Enter the amount of fuel you have (in liters):", "bot");
      }
    }

    else if (input.includes("how much fuel") || input.includes("need to travel")) {
      if (!data.efficiency) {
        pendingAction = "fuel_for_distance";
        addMessage("Please calculate your fuel efficiency first by typing 'calculate'.", "bot");
      } else {
        waitingFor = "fuel_for_distance";
        addMessage("Enter the distance you want to travel (in km):", "bot");
      }
    }

    else if (input.includes("tips")) {
      addMessage("💡 Fuel-saving tips:\n• Maintain steady speed\n• Avoid unnecessary idling\n• Check tire pressure\n• Travel light\n• Regular servicing", "bot");
    }

    else {
      addMessage("I'm a Fuel Tracker Bot! You can ask me to:\n• 'Calculate' fuel efficiency\n• 'How far can I travel with X liters?'\n• 'How much fuel do I need to travel Y km?'\n• 'Tips' to save fuel", "bot");
    }
  }
}
